
export default function Login() {
    return (
        <div>
            <h1>Login</h1>


            <div>
                <label>username</label>
                <input
                    type="text"
                    placeholder="username"
                />
            </div>

            <div>
                <label>password</label>
                <input
                    type="text"
                    placeholder="password"
                />
            </div>


            <button>
                Submit
            </button>
        </div>
    );
}
